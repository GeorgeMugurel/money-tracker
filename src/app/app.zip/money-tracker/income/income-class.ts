export class Income {
    _id: string;
    name: string;
    date: number;
    category: string;
}
