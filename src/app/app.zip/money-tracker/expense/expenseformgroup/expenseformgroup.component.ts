import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-expenseformgroup',
  templateUrl: './expenseformgroup.component.html',
  styleUrls: ['./expenseformgroup.component.css']
})
export class ExpenseformgroupComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
