import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editexpense',
  templateUrl: './editexpense.component.html',
  styleUrls: ['./editexpense.component.css']
})
export class EditexpenseComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
