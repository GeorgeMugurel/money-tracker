import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addexpense',
  templateUrl: './addexpense.component.html',
  styleUrls: ['./addexpense.component.css']
})
export class AddexpenseComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
